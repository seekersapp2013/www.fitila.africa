A Pen created at CodePen.io. You can find this one at https://codepen.io/gustavomodena/pen/adZgWK.

 A simple and cool full menu animation with CSS3 and JS. Just for practice.