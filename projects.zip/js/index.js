//fancybox begin
	$().fancybox({
		selector : '[data-fancybox="gallery1"],[data-fancybox="gallery2"]',
		thumbs: false,
		hash: true,
		loop: true
	 });