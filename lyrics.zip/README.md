# Markov Lyrics

## Notes
- using Genius's "public" API

## User flow

- Search for artist (https://genius.com/api/search/artist?q={{artist}})
- find an artist 
- Find their top 10 songs (https://genius.com/api/artists/{{artistID}}/songs?page=1&sort=popularity)
- Scrape their top 10 songs (https://page.rest)
- Generate a markov chain for top 10 songs, cache markov chain for x minutes. (store on jsonstore.io)
- Generate random lyrics and return as response.
