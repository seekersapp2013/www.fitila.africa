const express = require('express');
var cors = require('cors')
const path = require('path');

const {
  markovChainFromText,
} = require('./markov.js');

const {
  getArtistTopTen,
} = require('./api.js');

const {
  autocomplete,
  image,
} = require('./utils.js');


const app = express();
app.use(express.static('static'))
app.use(cors())


app.get('/generate', async (req, res) => {

  if (!req.query.q) {
    res.status(400);
    res.send('Invalid request: no search query');
    return;
  }

  if(req.query.q.toLowerCase()=="markov chain"){
    return res.send(`A Markov chain is a stochastic model describing a sequence of possible events in which the probability of each event depends only on the state attained in the previous event.

In probability theory and related fields, a Markov process, named after the Russian mathematician Andrey Markov, is a stochastic process that satisfies the Markov property (sometimes characterized as "memorylessness"). Roughly speaking, a process satisfies the Markov property if one can make predictions for the future of the process based solely on its present state just as well as one could knowing the process's full history, hence independently from such history; i.e., conditional on the present state of the system, its future and past states are independent.

A Markov chain is a type of Markov process that has either a discrete state space or a discrete index set (often representing time), but the precise definition of a Markov chain varies. For example, it is common to define a Markov chain as a Markov process in either discrete or continuous time with a countable state space (thus regardless of the nature of time), but it is also common to define a Markov chain as having discrete time in either countable or continuous state space (thus regardless of the state space).

Wanna read more? You should google.
`);
  }

  const seedWord = req.query.seed || '';
  const allLyrics = await getArtistTopTen(req.query.q);
  const m = markovChainFromText(allLyrics)
  res.send(m.predict(seedWord, req.query.n || 30));
});

app.get('/autocomplete', async (req, res) => {

  if (!req.query.q) {
    res.status(400);
    res.send('Invalid request: no search query');
    return;
  }

  let data = await autocomplete(req.query.q)
  res.send(data);
});

app.get('/image', async (req, res) => {
  
  if (!req.query.q) {
    res.status(400);
    return res.send('Invalid request: no search query');
  }
  if(req.query.q.trim().toLowerCase()=="markov chain"){
    return res.redirect("https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Markovkate_01.svg/220px-Markovkate_01.svg.png");
  }

  let data = await image(req.query.q)
  res.send(data);
});

app.get('/*', (req, res) => {
  res.sendFile(path.join(__dirname, 'static/index.html'))
});

app.listen(3002, () => {
  console.log('server started');
});
