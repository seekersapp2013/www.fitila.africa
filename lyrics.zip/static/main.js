const {
  StyledComponent,
  Router,
} = Torus;

const DEFAULT_LYRIC = 'loading lyrics...';

const apiGet = path => {
  return fetch(path, {
    cache: 'no-cache',
  });
}

const afterFrame = fn => {
  requestAnimationFrame(() => {
    requestAnimationFrame(fn);
  })
}

class App extends StyledComponent {
  init(router) {
    this.apiCalled = false;
    this.artistQuery = null;
    this.lyric = DEFAULT_LYRIC;

    this.searchBar = new SearchBar();
    this.handleDownloadClick = this.handleDownloadClick.bind(this);

    this.bind(router, ([name, params]) => {
      switch (name) {
        case 'search':
          this.handleSearch(decodeURIComponent(params.query));
          this.searchBar.forceSetInputValue(decodeURIComponent(params.query));
          break;
        default:
          // no-op
          break;
      }
    });
  }
  async handleSearch(query) {
    this.apiCalled = true;
    this.artistQuery = query;
    this.lyric = DEFAULT_LYRIC;
    this.render();

    this.lyric = await apiGet(`/generate?n=100&q=${encodeURIComponent(query.trim())}`).then(resp => resp.text());
    this.render();
  }
  handleDownloadClick() {
    if (typeof html2canvas !== 'undefined' && this.lyric !== DEFAULT_LYRIC) {
      html2canvas(document.querySelector("#lyric")).then(canvas => {
        const a = document.createElement('a');
        a.href = canvas.toDataURL();
        a.setAttribute('download', `rip-${this.artistQuery.replace(/\//g, '-').toLowerCase()}.png`);
        a.click();
      });
    }
  }
  styles() {
    return css`
    display: flex;
    flex-direction: column;
    align-items: center;

    max-width: 800px;
    width: 60%;
    margin: 16px auto;

    @media only screen and (max-width: 800px) {
      width: 96%;
    }

    header {
      text-align: center;
      font-size: 2.5em;
      font-weight: bold;
      margin-top: 18px;
      margin-bottom: 32px;
      a {
        text-decoration: none;
        color: var(--cf-accent);
        &:hover {
          text-decoration: underline;
        }
      }
    }

    .profilePic {
      padding: 0 !important;
      width: 206px;
      margin-top: -110px;
      transform: rotate(-3deg);
      margin-left: 12px;
      cursor: initial;
      img {
        height: 200px;
        width: 200px;
      }
    }

    .lyricBlock {
      margin-top: 120px;
      width: calc(100% - 10px);
      font-size: 1em;
      box-sizing: border-box;
      padding: 8px 12px;
      font-style: italic;
      line-height: 1.4em;
      cursor: initial;

      p:first-child {
        margin-top: 20px;
      }
    }

    .loading {
      margin: 4px auto;
      width: 28px;
      margin-top: 18px;
      margin-bottom: 32px;
      img {
        width: 100%;
      }
    }

    footer {
      text-align: center;
      margin-bottom: 32px;
      a {
        text-decoration: underline;
        color: var(--cf-accent);
      }
    }
    
    #lyric {
      background: var(--cf-background);
      width: 100%;
    }

    .about {
      text-align: center;
      max-width: 500px;
      a {
        text-decoration: underline;
      }
    }

    .downloadContainer {
      .height: 0;
      overflow: visible;
      display: flex;
      flex-direction: row-reverse;
      align-items: center;
      justify-content: flex-start;
      position: relative;
      width: 100%;
      z-index: 10;
    }
    .downloadButton {
      color: var(--cf-accent);
      position: absolute;
      right: 0;
      top: 58px;
      left: unset;
      bottom: unset;
      flex-grow: 0;
      width: auto;
      text-align: center;
      font-size: 1em;
    }
    `;
  }
  compose() {
    const lnk = query => {
      return jdom`<a href="/s/${query}"
        onclick="${evt => {
          evt.preventDefault();
          router.go('/');
          router.go(`/s/${query}`);
        }}"
        >${query}</a>`;
    }
    return jdom`<main>
      ${Header()}
      <p class="about">
        Generate lyrics like they're from ${lnk('Drake')} or ${lnk('Rihanna')}
        –
        all magic done by a ${lnk('Markov Chain')}
      </p>
      ${this.searchBar.node}
      ${this.lyric !== DEFAULT_LYRIC ? jdom`<div class="downloadContainer">
        <button class="downloadButton button"
          onclick="${this.handleDownloadClick}"
          >
          Save <span class="desktop">as Image</span>
        </button>
      </div>` : null}
      ${this.apiCalled ?
        LyricBlock(this.artistQuery, this.lyric)
        : null}
      ${Footer()}
    </main>`;
  }
}

const Header = () => {
  return jdom`<header>
    <a href="/">
      lyrics.rip
    </a>
  </header>`;
}

const Footer = () => {
  return jdom`<footer>
    <p>Made with &#60;3 by 
      <a href="https://twitter.com/thesephist">@thesephist</a>
      and
      <a href="https://twitter.com/jajoosam">@jajoosam</a>
    </p>
  </footer>`;
}

const LyricBlock = (artist, lyric) => {
  let loader = null
  if (lyric === DEFAULT_LYRIC) {
    loader = jdom`<div class="loading">
      <img src="/grid.svg"/>
    </div>`;
  }
  return jdom`<div id="lyric"><div class="lyricBlock fixed button">
    <div class="profilePic fixed button">
      <img src="/image?q=${encodeURIComponent(artist)}"/>
    </div>
    ${lyric.split('\n').map(line => jdom`<p>${line}</p>`)}
    ${loader}
  </div>
  </div>`;
}

const AutoCompleteItem = (query, tabSelected) => {
  return jdom`<div class="autoCompleteItem ${tabSelected ? 'selected' : ''}"
    onclick="${() => router.go(`/s/${query}`)}"
    >
    ${query}
  </div>`;
}

const AutoCompleteDropdown = (queries, tabIdx) => {
  return jdom`<div class="autoCompleteDropDown">
    ${queries.map((query, idx) => AutoCompleteItem(query, idx === tabIdx))}
  </div>`;
}

const debounce = (fn, delayMillis) => {
    let lastRun = 0;
    let to = null;
    return (...args) => {
        clearTimeout(to);
        const now = Date.now();
        const dfn = () => {
            lastRun = now;
            fn(...args);
        }
        if (now - lastRun > delayMillis) {
            dfn()
        } else {
            to = setTimeout(dfn, delayMillis);
        }
    }
}

class SearchBar extends StyledComponent {
  init() {
    this.inputVal = '';
    this.inputFocused = false;
    this.autoCompletes = null;
    this.tabIdx = -1;
    this.searchedCallback = query => {
      router.go('/');
      router.go(`/s/${query}`);
    }

    this.handleInput = this.handleInput.bind(this);
    this.handleFocused = this.handleFocused.bind(this);
    this.handleBlur = this.handleBlur.bind(this);
    this.handleKeydown = this.handleKeydown.bind(this);
    this.handleSearchClick = this.handleSearchClick.bind(this);
    this.updateDropDown = debounce(this.updateDropDown.bind(this), 400);
  }
  forceSetInputValue(value) {
    this.inputVal = value;
    this.render();
  }
  handleInput(evt) {
    this.inputVal = evt.target.value;
    this.updateDropDown();
  }
  handleFocused() {
    this.inputFocused = true;
    this.render();
  }
  handleBlur() {
    setTimeout(() => {
      this.inputFocused = false;
      this.render();
    }, 200);
  }
  async updateDropDown() {
    if (this.inputVal === '') {
      return;
    }
    
    this.autoCompletes = await apiGet(`/autocomplete?q=${this.inputVal}`)
      .then(resp => resp.json());
    this.autoCompletes = this.autoCompletes.slice(0, 5);
    this.render();
  }
  handleKeydown(evt) {
    if (evt.keyCode === 13 || evt.key == 'Enter') {
      this.handleSearchClick();
      this.tabIdx = -1;
    } else if (evt.key === 'Tab') {
      if (this.autoCompletes !== null) {
        evt.preventDefault();
        this.tabIdx = Math.min(this.tabIdx + 1, this.autoCompletes.length - 1);
        this.inputVal = this.autoCompletes[this.tabIdx];
        this.render();
      }
    } else {
      this.tabIdx = -1;
    }
  }
  handleSearchClick() {
    this.autoCompletes = null;
    this.searchedCallback(this.inputVal);
    this.render();
  }
  styles() {
    return css`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-around;
    width: 100%;
    .inputContainer {
      flex-grow: 1;
      position: relative;
      z-index: 100;
      height: 40px;
      input {
        width: 100%;
        height: 100%;
        margin: 0;
        box-sizing: border-box;
        border: 0 !important;
        font-weight: bold;
        font-size: 1em;
        outline: none !important;
      }
    }
    button.button {
      padding: 6px 10px;
      font-size: 1em;
      height: 40px;
    }
    .autoCompleteDropdown {
      background: #f3f3f3;
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      border: 3px solid var(--cf-black);
      border-top: 0;
    }
    .autoCompleteItem {
      border-top: 1px solid #aaa;
      padding: 6px 8px;
      cursor: pointer;
      z-index: 200;
      &:hover,
      &.selected {
        background: #ddd;
      }
      &:active {
        background: #bfbfbf;
      }
    }
    `;
  }
  compose() {
    return jdom`<div class="searchBar">
      <div class="inputContainer fixed button">
        <input type="search" placeholder="Search for an artist..."
          oninput="${this.handleInput}"
          onkeydown="${this.handleKeydown}"
          onfocus="${this.handleFocused}"
          onblur="${this.handleBlur}"
          value="${this.inputVal}"
          autofocus/>
        ${this.autoCompletes && this.inputFocused
          ? AutoCompleteDropdown(this.autoCompletes, this.tabIdx)
          : null}
      </div>
      <button class="button active"
        onclick="${this.handleSearchClick}"
        >Generate</button>
      </div>`;
  }
}

const router = new Router({
  search: '/s/:query',
  default: '/',
});

const app = new App(router);
document.body.appendChild(app.node);
