const axios = require('axios');

const CACHE = new Map();

const cachedGet = url => {
  if (CACHE.has(url)) {
    return CACHE.get(url);
  } else {
    const axiosResponse = axios.get(url);
    CACHE.set(url, axiosResponse);
    return axiosResponse;
  }
}

let getArtistTopTen = artist => {
  return new Promise((res, rej) => {
  axios.get(`https://genius.com/api/search/artist?q=${artist}`)
    .then(function (response){
      var result = response.data.response.sections[0].hits[0].result;
      var data = {
        id: result.id,
        name: result.name,
        image: result.image_url
      }
      cachedGet(`https://genius.com/api/artists/${data.id}/songs?page=1&sort=popularity`)
        .then(async response => {
          var rawSongs = response.data.response.songs;
          var songs = rawSongs.map(song => `https://genius.com${song.path}`)
          const songDataPromises = songs.map(url => {
            return cachedGet(`https://page.rest/fetch?token=${process.env.PR}&url=${url}&selector=.lyrics`).catch(e => console.log(e));
          });
          
          const lyricArray = await Promise.all(songDataPromises);
          let allLyrics = lyricArray.map(lyric => lyric.data)
            .map(lyric => lyric.selectors['.lyrics'][0].text)
            .map(lyric => lyric.replace(/\[.*\]/g, ''))
            .join('\n');
          res(allLyrics);
        });
    }).catch(err => rej(err));
  });
}

module.exports = {
  getArtistTopTen,
}