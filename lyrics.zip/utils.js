const axios = require('axios');

let image = async artist => {
  const response = await axios.get(`https://genius.com/api/search/artist?q=${artist}`)
  var imageUrl = response.data.response.sections[0].hits[0].result.image_url;
  const imageBuffer = await axios.get(imageUrl, {
      responseType: 'arraybuffer'
  });
  return imageBuffer.data;
}

let autocomplete = async artist => {
  const response = await axios.get(`https://genius.com/api/search/artist?q=${artist}`)
  // console.log(response.data.response.sections[0].hits)
  var suggestions = response.data.response.sections[0].hits.map(artistSuggestion => artistSuggestion.result.name);
  // console.log(suggestions);
  return suggestions;
}

module.exports = {
  autocomplete,
  image,
}