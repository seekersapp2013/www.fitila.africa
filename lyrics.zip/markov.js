// something that won't conflict with real words
const NEWLINE = '____newline';

const randInRange = max => {
  return ~~(Math.random() * max);
}

class MarkovChain {
  constructor() {
    this.chain = {};
  }

  registerPair(prev, next) {
    const nextDict = this.chain[prev] || {};
    const nextWordVal = nextDict[next] || 0;
    nextDict[next] = nextWordVal + 1;
    this.chain[prev] = nextDict;
  }

  predictOne(prev) {
    if (Object.keys(this.chain).length === 0) {
      throw new Error('Cannot predict on an uninitialized Markov Chain');
    }

    const nextDict = this.chain[prev];
    if (nextDict === undefined) {
      const keys = Object.keys(this.chain);
      const randIdx = randInRange(keys.length);
      return keys[randIdx];
    } else {
      const sum = Object.values(nextDict).reduce((prev, n) => prev + n, 0);
      const rand = randInRange(sum);

      let runningCount = 0;
      const keys = Object.keys(nextDict);
      for (const key of keys) {
        runningCount += nextDict[key];
        if (rand <= runningCount) {
          return key;
        }
      }
      return keys[0];
    }
  }

  predict(prev, n = 1) {
    let result = [prev];
    while (n --> 0) {
      prev = this.predictOne(prev);
      switch (prev) {
        case 'i':
          result.push('I');
          break;
        case NEWLINE:
          result.push('\n');
          break;
        default:
          result.push(prev);
          break;
      }
    }
    const sentence = result.join(' ').trim()
      .split('\n').map(s => s.trim())
      .map(s => s.charAt(0).toUpperCase() + s.substr(1))
      .join('\n');
    return sentence;
  }
}

const textToWords = text => {
  return text.trim().toLowerCase()
    .replace(/\n+/g, ' ' + NEWLINE + ' ')
    .replace(/[\.\"\(\)]/g, ' ').replace(/ +/g, ' ')
    .split(' ');
}

const markovChainFromText = text => {
  const words = textToWords(text);
  const markov = new MarkovChain();
  for (let i = 0, max = words.length - 1; i < max; i ++) {
    markov.registerPair(words[i], words[i+1]);
  }
  return markov;
}

module.exports = {
  markovChainFromText,
}
