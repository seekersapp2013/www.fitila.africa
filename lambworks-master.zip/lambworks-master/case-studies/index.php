<?php
  // include('../inc/contact-mailer.php');
  include('../inc/header.php');
?>

<div class="">
  <?php include('../inc/nav.php');?>
</div>

<?php
  // include('../inc/contact-form.php');
  include('../inc/footer.php');
?>
