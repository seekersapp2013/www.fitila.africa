    <footer>
      <div class="row">
        <div class="large-10 medium-12 large-centered columns">
          <div class="large-5 large-offset-1 medium-12 columns">
            <p>&copy; <?php echo date('Y') ?> Lambworks</p>
          </div> <!-- /.large-5 large-offset-1 medium-12 columns -->
        <div class="large-6 medium-12 columns">
          <p>Developed by <a href="http://www.flipcampbell.com">Flip Campbell</a></p>
        </div><!-- /.large-6 medium-12 columns -->
        <?php /*
        <div class="large-3 large-offset-1 medium-12 columns">
          <p><a href="#">Credits</a></p>
        </div>
        */ ?>
        </div> <!-- /.large-10 medium-12 large-centered columns -->
      </div> <!-- /.row -->
    </footer>
    <script type="text/javascript" src="/js/retina.js"></script>
    <script src="/js/app.js"></script>
  </body>
