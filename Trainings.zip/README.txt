A Pen created at CodePen.io. You can find this one at https://codepen.io/babalola/pen/LvYddL.

 My submission for week #1 of the Weekly Coding Challenge. Read more here: https://www.florin-pop.com/blog/2019/03/weekly-coding-challenge